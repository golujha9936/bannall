from pyrogram import idle
from . import bot
bot.start()
idle()
bot.stop()
