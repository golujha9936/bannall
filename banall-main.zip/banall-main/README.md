# Banall bot

Telegram Ban all Bot Which can Remove All members easily ...

## Deploy
U can Deploy Easily Fork repo and Give Started ✨

## ʜᴇʀᴏᴋᴜ ᴅᴇᴘʟᴏʏᴍᴇɴᴛꜱ 💜
ʜᴇʀᴏᴋᴜ ɪꜱ ᴛʜᴇ ᴇᴀꜱʏ ᴡᴀʏ ᴛᴏ ʜᴏꜱᴛ ᴜʀ ᴀᴘᴘꜱ

[![ᴢᴠᴄ ᴅᴇᴘʟᴏʏ](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/AellyXD/Banall)
## Note

I m Not Responsible For anything Use This Code At Own Risk And Don't Ask Me In Support Groups About This Codes..
 Enjoy 🙂


## How to Use.

That's a Simple Code Just deploy Bot then Simply make them Via searching Add new Admin Section or make directly admin with Ban Rights.
